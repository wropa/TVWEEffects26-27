// Ждем загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
  const navLinks = document.querySelectorAll(".topbar a");

  navLinks.forEach(link => {
    link.addEventListener("click", (e) => {
      // Убираем класс active у всех ссылок
      navLinks.forEach(item => item.classList.remove("active"));
      // Добавляем класс active текущей ссылке
      link.classList.add("active");
    });
  });
});